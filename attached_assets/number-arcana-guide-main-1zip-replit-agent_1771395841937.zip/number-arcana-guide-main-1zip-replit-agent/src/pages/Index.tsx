import { NumerologyCalculator } from '@/components/NumerologyCalculator';

const Index = () => {
  return <NumerologyCalculator />;
};

export default Index;
